`oai-cn5g-upf-vpp` repository is distributed under **Apache V2.0 License**.

For more details of the license, refer to [LICENSE](LICENSE) file in the same directory.

However, it also includes OAI code or third party-software indicated below.

* **`src/nrf_client.py`** is dstributed under `OAI Public License V1.1`.
