<table style="border-collapse: collapse; border: none;">
  <tr style="border-collapse: collapse; border: none;">
    <td style="border-collapse: collapse; border: none;">
      <a href="http://www.openairinterface.org/">
         <img src="./images/oai_final_logo.png" alt="" border=3 height=50 width=150>
         </img>
      </a>
    </td>
    <td style="border-collapse: collapse; border: none; vertical-align: center;">
      <b><font size = "5">OpenAirInterface Core Network Docker Deployment Home Page</font></b>
    </td>
  </tr>
</table>

**Table of Contents**

1.  [Pre-requisites](https://gitlab.eurecom.fr/oai/cn5g/oai-cn5g-fed/-/blob/master/docs/DEPLOY_PRE_REQUESITES.md)
2.  [Installing VPP-UPF on host](./INSTALL_ON_HOST.md)
3.  [Building the Docker Image](./BUILD_IMAGE.md)
4.  [About network configuration](./VPP_NETWORKING.md)
5.  [About VPP-UPF configuration](./VPP_UPF_CONFIG.md)
6.  [About VPP-UPF configuration with DPDK](./VPP_UPG_WITH_DPDK.md)
7.  [About VPP-UPF command line interface (CLI)](./VPP_UPG_CLI.md)
8.  [UPF bracket testing](./UPF_BRACKET_TESTING.md)
